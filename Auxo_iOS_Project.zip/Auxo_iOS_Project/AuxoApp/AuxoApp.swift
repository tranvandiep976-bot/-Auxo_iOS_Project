import UIKit
import WebKit

@main
final class AuxoApp: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = ViewController()
        window?.makeKeyAndVisible()
        return true
    }
}

final class ViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    private var webView: WKWebView!
    private let hwidKey = "auxo.hwid"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let content = WKUserContentController()
        content.add(self, name: "licenseStore")

        let config = WKWebViewConfiguration()
        config.userContentController = content
        config.allowsInlineMediaPlayback = true
        config.preferences.javaScriptEnabled = true

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .black
        view.addSubview(webView)
        webView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        if let url = Bundle.main.url(forResource: "app", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
    }

    deinit { webView?.configuration.userContentController.removeScriptMessageHandler(forName: "licenseStore") }

    private func stableHWID() -> String {
        if let saved = UserDefaults.standard.string(forKey: hwidKey), !saved.isEmpty { return saved }
        let uuid = UUID().uuidString.replacingOccurrences(of: "-", with: "").suffix(12).uppercased()
        let value = "HT-\(uuid)"
        UserDefaults.standard.set(value, forKey: hwidKey)
        return value
    }

    private func sendNativeInfo() {
        let model = UIDevice.current.model
        let ios = UIDevice.current.systemVersion
        let identifier = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        let hwid = stableHWID()
        let js = "window.setNativeDeviceInfo(\(json(model)), \(json(ios)), \(json(identifier)), \(json(hwid)));"
        webView.evaluateJavaScript(js, completionHandler: nil)
        if let key = UserDefaults.standard.string(forKey: "auxo.licenseKey"), !key.isEmpty {
            webView.evaluateJavaScript("window.setNativeLicenseKey(\(json(key)));", completionHandler: nil)
        }
    }

    private func json(_ value: String) -> String {
        let data = try! JSONSerialization.data(withJSONObject: [value], options: [])
        let array = String(data: data, encoding: .utf8)!
        return String(array.dropFirst().dropLast())
    }

    private func openGame(_ game: String) {
        // Change these two schemes if your installed game build uses different URL schemes.
        let scheme = game == "ffmax" ? "freefiremax://" : "freefire://"
        guard let url = URL(string: scheme) else { return }
        UIApplication.shared.open(url, options: [:]) { [weak self] success in
            if !success {
                self?.showMessage("Không mở được game", "Hãy cài Free Fire/Free Fire MAX hoặc kiểm tra URL scheme của bản game.")
            }
        }
    }

    private func showMessage(_ title: String, _ message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "licenseStore", let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "openGame":
            openGame(body["game"] as? String ?? "ff")
        case "save":
            if let key = body["key"] as? String, !key.isEmpty { UserDefaults.standard.set(key, forKey: "auxo.licenseKey") }
        case "clear":
            UserDefaults.standard.removeObject(forKey: "auxo.licenseKey")
        default:
            break
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        sendNativeInfo()
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            UIApplication.shared.open(url)
        }
        return nil
    }
}
